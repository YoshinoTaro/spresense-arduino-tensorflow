                        How to use tiny_filer


OVERVIEW:

    The tiny_filer is a tiny filer for Flash device on SPRESENSE.

USAGE:

    * Execute tiny_filer then root directory is shown.

    * all files and directories on current directory are shown
      with number, path and additional information.
      - For directories, additional information is just "<DIR>".
      - For other files, additional information is file size.

    * Type number and Enter to
      - move the directory.
      - show the (text) file.

    * Type '0' and Enter to move root directory.

    * Type 'd' + number to remove the file or directory.
      < WARNING > tiny_filer remove the file or directory
                  without any confirmation.
                  Please be careful.
